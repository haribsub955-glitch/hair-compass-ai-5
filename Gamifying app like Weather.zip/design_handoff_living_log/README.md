# Handoff: Living Inputs for the Daily Log

## Overview
Extends the app's signature shedding control — *"the answer literally **is** the
simulation"* — to **every** field in the daily log. Today only `shed` (a `ShedDialField`)
and `cigarettes` / `alcohol` (a `CountScrubber`) react to your drag. The six remaining
fields — **flaking, redness, itch, oiliness, sleep quality, stress** — are still plain
`PipStepper` rows. This handoff turns each of those into a drag-to-simulate "living
gauge" whose animated preview *is* the thing being measured.

## About the design file
`Daily Log — Living Inputs.dc.html` is a **high-fidelity interaction prototype** built in
an HTML tool (HTML5 `<canvas>` + a `requestAnimationFrame` loop), not shippable code. It
faithfully shows the motion, feel, colours, copy and drag behaviour to recreate natively
in SwiftUI. It only runs inside the design tool. Recreate it using the app's existing
`Clinical` tokens and the Canvas/TimelineView pattern the app already uses — no new
dependencies, **no new data model**.

## Fidelity
High-fidelity. Every motif, colour, caption, band label and the drag grammar are final.
The particle counts / physics constants in the prototype's `draw*` functions are the
tuned values — port them across.

---

## What ALREADY exists — reuse, don't rebuild
The "input is the preview" family is already shipped and is the template for all of this:

- **`Feature/Controls/ShedDialField.swift`** — the exact shell to generalize: a 140pt
  live preview panel + a copper drag track + zone labels, continuous drag driving the
  sim, band derived from thumb position. Interaction grammar lives here: zero-distance
  drag so **taps jump**, `UISelectionFeedbackGenerator` **only when the band changes**,
  `accessibilityAdjustableAction`, and a Reduce-Motion static path.
- **`Feature/Onboarding/HairPhysics.swift`** — `HairSim` + `FallingHairView`: the shared
  `Canvas` + `TimelineView(.animation)` particle engine. The new **flaking** motif is a
  near-clone of this (spawn-rate/gravity scale with intensity; render flecks not strands).
- **`Feature/Controls/CountScrubber.swift`** — already renders a per-value `Canvas` motif
  (smoke wisps / condensation drops) via `TimelineView`. This is the reference for the new
  **field/ripple/waveform** motifs — same structure, different `draw*`. Cigarettes &
  alcohol keep this control unchanged.
- **`Feature/Onboarding/OnboardingComponents.swift`** — `SheddingDial.band(_:)` /
  `bandCaption(_:)`: the `intensity(0…1) → band` mapping. Reuse `band(i) = round(i*3)`
  verbatim for the four 0–3 gauges; use `1 + round(i*4)` for the two 1–5 gauges.
- **`Design/Clinical.swift`** — all colours/shape/type tokens. `PipStepper` (the control
  being replaced for these six fields) also lives here — leave it; other screens still use it.

## What's NEW / missing (the ask)
1. **One generalized control** — `LivingGauge` — factored out of `ShedDialField` so the
   shell (preview panel + track + captions + zone labels + drag grammar + a11y) is written
   once and takes a **motif** + a value binding + a caption model.
2. **Six new Canvas motif renderers**, one per field (algorithms below).
3. **`LogSheet.swift` swap** — replace the six `PipStepper` rows with `LivingGauge`s.
4. **Live scalp severity in the section header** — the `flaking + redness + itch`
   composite (`HairAnalytics.scalpTotal` → `x/16 · Band`) shown on the right of the
   "Scalp signs" header, updating as you drag (the prototype shows `12/16 · High`).

**No data-model work.** All six values already exist on `DailyEntry`
(`flaking`, `erythema`, `itch`, `oiliness`, `sleepQuality`, `stress`) with the same
ranges. This is purely an input-control swap — no `@Model` change, no migration.

---

## Recommended architecture

### `Feature/Controls/LivingGauge.swift` (new)
Generalize `ShedDialField` into a reusable control. Keep its drag grammar **exactly**.

```swift
struct LivingGauge<Motif: View>: View {
    @Binding var intensity: CGFloat          // 0…1, the source of truth while dragging
    let bandCount: Int                       // 4 (0–3 fields) or 5 (1–5 fields)
    let tint: Color                          // thumb / fill / active-zone colour
    let zones: [String]?                     // 4 zone labels, or nil → show end labels
    let ends: (String, String)?              // ("POOR","DEEP") etc. for 5-level gauges
    let caption: (CGFloat) -> (String, String)   // live (title, subtitle)
    @ViewBuilder let motif: (CGFloat) -> Motif    // the animated preview, fed intensity

    // body: previewPanel(motif + caption overlay) + dragTrack(bar/thumb + labels)
    // Lift previewPanel + dragTrack + setBand + the DragGesture VERBATIM from
    // ShedDialField.swift — only the motif view and caption/zone data are parameterized.
}
```
Band from intensity: `min(bandCount-1, max(0, Int((intensity*(bandCount-1)).rounded())))`.

### `Feature/Controls/LogMotifs.swift` (new)
Each motif is a `TimelineView(.animation(paused: reduceMotion)) { Canvas { … } }` exactly
like `FallingHairView` / `CountScrubber.motifLayer`. `intensity` (0…1) drives everything;
`reduceMotion` draws one representative static frame. Port the constants from the
prototype's `draw*` functions — they map 1:1 to `GraphicsContext`.

- **FlakeMotif** (flaking) — clone `HairSim`: `spawnRate = 0.5 + i*i*11`, fall speed
  `(0.5 + i*0.9)`, drift sway; render small **ellipses** (r `1…1+i*2.4`, bigger = clumps)
  in `#EFE6D6` / `Clinical.tertiary` at α `0.55*fade`. (Prototype: `drawFlake`.)
- **RednessMotif** (erythema) — a **field wash**, no particles: `fillRect` in
  `Clinical.critical` at α `i*0.22` + two breathing radial blooms (`#B44A34`), whole panel
  flushes red as `i` rises; α gently pulses `0.92 + 0.08*sin(t*1.8)`. (Prototype: `drawRed`.)
- **ItchMotif** (itch) — **prickle ripples**: spawn expanding rings at random points at
  rate `0.25 + i*i*6`; each ring grows r `3→20` and fades over 0.72 s, stroke
  `Clinical.warning`. More frequent as `i` rises. (Prototype: `drawItch`.)
- **OilMotif** (oiliness) — **gloss sheen**: base gold wash α `i*0.16` + a specular
  highlight band sweeping horizontally (`sin(t*0.55)`) + two soft gloss blobs; brighter &
  larger with `i`. Gold `#C9A15A` / `#FFFDF6`. (Prototype: `drawOil`.)
- **SleepMotif** (sleepQuality, 1–5) — **night calm**: a breathing sine wave that gets
  *calmer* as quality rises (`freq = 0.03 + (1-q)*0.10`, `amp = 5 + (1-q)*11`), plus
  `floor(q*7)` twinkling gold stars and a crescent moon that grows with `q`. Wave in
  `Clinical.ink`. (Prototype: `drawSleep`.)
- **StressMotif** (stress, 1–5) — **seismograph**: a scrolling readout line, flat/calm at
  low, jagged at high (`amp = 3 + s²*30`, `freq = 0.05 + s*0.14`, hash-noise jitter `s²`),
  colour lerps `Clinical.ink → Clinical.critical`, with a scan dot at the right edge.
  (Prototype: `drawStress`.)

Deterministic per-particle randomness: reuse `CountScrubber`'s `hash(_:_:)` / `fract(_:)`
(already in the codebase) — the prototype uses the identical hash.

### Caption + band tables
Reuse the app's real captions where they exist; the prototype's tables are drop-in:

| Field | Range | Zone labels | Titles (prototype) |
|---|---|---|---|
| flaking | 0–3 | NONE · POWDERY · VISIBLE · ADHERENT | No flaking / Powdery / Visible flakes / Adherent |
| erythema | 0–3 | NONE · MILD · MODERATE · MARKED | No redness / Mild / Moderate / Marked redness |
| itch | 0–3 | NONE · MILD · MODERATE · MARKED | No itch / Mild / Moderate / Marked itch |
| oiliness | 0–3 | NORMAL · SLIGHT · OILY · VERY | Balanced / Slightly oily / Oily / Very oily |
| sleepQuality | 1–5 | ends POOR…DEEP | Poor / Restless / Okay / Good / Deep |
| stress | 1–5 | ends CALM…HIGH | Calm / Steady / Moderate / Tense / High |

(`flaking`/`oiliness` captions already exist as `flakingCaption`/`oilinessCaption` in
`LogSheet.swift`; `erythema`/`itch` use `level3Caption`. Keep those as the source of truth
and add only the short subtitle line.)

### `Feature/LogSheet.swift` integration
Keep the whole `NavigationStack` / `section(...)` / `save()` / `loadExisting()` scaffold
**unchanged**. Only swap the controls:

```swift
// Scalp signs — was three PipSteppers + an oiliness PipStepper
section(variable: "scalp") {
    LivingGauge(intensity: $flakeI, bandCount: 4, tint: Clinical.secondary,
                zones: ["NONE","POWDERY","VISIBLE","ADHERENT"], ends: nil,
                caption: flakeCaption) { i in FlakeMotif(intensity: i) }
    LivingGauge(intensity: $redI,  bandCount: 4, tint: Clinical.critical, …) { i in RednessMotif(intensity: i) }
    LivingGauge(intensity: $itchI, bandCount: 4, tint: Clinical.warning,  …) { i in ItchMotif(intensity: i) }
    LivingGauge(intensity: $oilI,  bandCount: 4, tint: Clinical.gold,     …) { i in OilMotif(intensity: i) }
}
// Wellbeing
section("Wellbeing") {
    LivingGauge(intensity: $sleepI,  bandCount: 5, tint: Clinical.ink,      ends: ("POOR","DEEP"), …) { i in SleepMotif(intensity: i) }
    LivingGauge(intensity: $stressI, bandCount: 5, tint: Clinical.critical, ends: ("CALM","HIGH"), …) { i in StressMotif(intensity: i) }
    CountScrubber(title: "Cigarettes today", value: $cigarettes, range: 0...60, tint: Clinical.warning, motif: .smoke)
    CountScrubber(title: "Alcoholic drinks", value: $alcoholDrinks, range: 0...30, tint: Clinical.secondary, motif: .drops)
}
```
Store each gauge as a `CGFloat` intensity `@State` and bridge to the model on the existing
`.onAppear`/`save()`: `flaking = Int((flakeI*3).rounded())` etc.; seed intensity from the
stored value on load (`flakeI = CGFloat(e.flaking)/3`) — same round-trip `ShedDialField`
already does with `shed`.

**Live scalp severity in the header:** give `VariableSectionHeader` (or a small custom
header for `"scalp"`) a trailing readout of
`HairAnalytics.scalpTotal(flaking:erythema:itch:)` → `"\(total)/16 · \(band.title)"`,
coloured `Clinical.bandColor(band)`. The prototype computes and shows this live as you drag.

---

## Interaction grammar to preserve (already in ShedDialField / CountScrubber)
- Zero-distance `DragGesture(minimumDistance: 0)` so a **tap jumps** to that spot / zone.
- `UISelectionFeedbackGenerator().selectionChanged()` **only when the discrete band/level
  changes**, never per pixel.
- `accessibilityElement(children: .ignore)` + `accessibilityAdjustableAction` (increment /
  decrement the band), value = the caption title.
- **Reduce Motion:** draw one static representative frame (see `FallingHairView.drawStatic`
  and `CountScrubber`'s `paused:` timeline) — never animate. Every motif above has a
  meaningful static state (a scatter of flecks, a red wash, a still wave, etc.).

## Design tokens
No new tokens. Motif/tint mapping (all from `Clinical`): shedding→`accent`,
flaking→`secondary`, redness→`critical`, itch→`warning`, oiliness→`gold`, sleep→`ink`,
stress→`critical`, cigarettes→`warning`, alcohol→`sage`. Preview panel = `Clinical.surface`,
16pt radius, hairline border (redness panel a hair warmer, `#FDF5EF`, so the flush reads).

## Data model / persistence
**Unchanged.** `flaking`, `erythema`, `itch`, `oiliness`, `sleepQuality`, `stress` already
exist on `DailyEntry` with these exact ranges. No migration. `scalpTotal`/`scalpBand`
helpers already exist in `HairAnalytics`.

## Files in this bundle
- `README.md` — this document.
- `Daily Log — Living Inputs.dc.html` — interactive reference prototype. Open in the
  design tool; drag any panel. The `draw*` functions in its script are the tuned motif
  algorithms to port to SwiftUI `Canvas`.
