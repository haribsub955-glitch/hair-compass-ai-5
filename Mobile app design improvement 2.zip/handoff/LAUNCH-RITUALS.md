# Hair Compass — Launch Rituals

Handoff spec for the "launch ritual" feature: a short, satisfying, destressing interaction that
greets the user on some app opens, themed around hair care. Prototyped and approved in
`Pull to Start.dc.html` (included in this folder — open in a browser to feel the physics;
the relevant reference is section **5a Launch ritual roulette**, plus 3a/4a/4b/4c for each ritual).

Target: SwiftUI, iOS. All drawing is procedural (Canvas / TimelineView at 60fps) except three
image assets (below). Follow `docs/DesignSystem.md` tokens throughout.

---

## 1. Trigger rules

- On cold launch (and foreground after > 4h background), roll a ritual with probability **1/3**
  (make this a remote-configurable constant; prototype exposes every-launch / 1-in-2 / 1-in-3).
- Never show the same ritual twice in a row (persist `lastRitualKind`).
- Non-ritual launches go straight to the app. No ritual on first-ever launch (onboarding owns that).
- The ritual is always **skippable**: any tap on a "skip" affordance (small ✕ or swipe down)
  dismisses instantly. Never gate core functionality on completing it.
- Completion should take 5–15 seconds of play.

## 2. Shared visual system

- Background: Canvas ivory `#FBF6EF`, with the **botanical BrandArt backdrop** (`comb-bg.png`)
  full-bleed at 90% opacity behind the interaction.
- Copy block, centered, top ≈ 66pt:
  - Eyebrow: `HAIR COMPASS` — SF Mono semibold 10.5, tracking 2, color `#A69687`
  - Title: serif (New York) bold 34, color `#2B211A` (per-ritual, see below)
  - Hint: SF 13.5, color `#6B5A4C` (per-ritual)
- Liquid/strand color: copper `#C9762F` family; espresso shadow `rgba(43,33,26,0.25)`;
  gold shift target `#C9A15A`; highlight cream `#FFF3DC`.
- Finish sequence (all rituals): interaction fades out over 0.9s (backdrop fades too) → the
  destination screen fades/de-blurs in (opacity 0→1, blur 10→0, 0.7s) ≈ 0.65s after finish.
  Serum uses a burst instead: a flat copper circle expands from the completion point covering
  the screen, then fades as the destination is revealed; 28 droplet particles fly outward
  (gravity 0.3/frame, shrink ×0.99/frame).
- Add soft haptics: light impact on each satisfying event (bubble pop, drop plink, strand
  fully smoothed), success haptic on completion. (Prototype has none — HTML.)

## 3. The four rituals

### 3.1 Combing (`comb`)
Title "Comb it smooth" · Hint "Run your finger down each strand."
- 5 vertical locks, x = 22%…78% of width, y from 30% to 85% of height, 26 points each.
- Each point: amplitude `a = 10 + rand*16`, smoothness `s = 0`.
- Idle sway: `xOffset = sin(j*freq + phase + t/1.6s) * a * (1 - s) + sin(t/2.4s + phase) * 2.5`,
  freq `0.45 + rand*0.25` per lock.
- Combing: while dragging, any point within 58pt of the finger gains
  `s += 0.13 * (1 - d/58) + 0.02` per frame (clamped to 1).
- Rendering per lock, 3 strokes over the same path: espresso shadow (offset +1.6, width 5),
  main color (width 3.5) mixed `#8A5A38 → #C9A15A` by lock-average s × 0.75, cream highlight
  (offset −1.1, width 1.3, alpha grows with s). Round caps/joins.
- Reward: when a lock's average s > 0.985, a soft light blob (radius 16, cream) sweeps down
  the lock over 0.7s.
- The **comb asset** (`comb-tool.png`) follows the finger while dragging, rotated ≈ −14°,
  ~130pt wide, teeth at the fingertip. Tiny cream sparkle particles drift up from the finger.
- Complete at overall average s > 0.94.

### 3.2 Scalp massage (`massage`)
Title "Massage in circles" · Hint "Rub gently — the lather builds as you go."
- Rubbing (drag speed > 1.5pt/frame, below top 30% of screen) spawns foam bubbles at the
  finger (spawn chance ∝ speed, cap 0.8/frame): start r 2–5, grow toward max 7–22
  (`r += (max−r)*0.04`), drift up slowly, lifetime 1.8–3.4s.
- Bubble look: cream fill `#F0D9B8` at 35%, white rim 1.6pt at 85%, small white highlight dot.
- Pop: at end of life, or when the finger touches a bubble older than 0.35s → expanding white
  ring (r → r+14 over 0.38s, fading). This is the main satisfying beat — pair with light haptic.
- Progress: `+= dragSpeed * 0.00028` per frame; shown as a thin copper ring (r 24) at bottom
  center. Full ring → finish.

### 3.3 Serum drops (`serum`)
Title "One drop at a time" · Hint "Hold to fill the drop, release to let it fall."
- Glass dropper drawn at top center (tip at 37% height): bulb r 17 + tapering body, stroked
  dark copper at 55%, translucent fill, inner serum fill at 80%.
- Hold anywhere: drop at the tip swells `charge += 0.02/frame` (r = 3 + charge*12, slight
  wobble). Release: drop falls (gravity 0.55/frame²).
- Pool at bottom: 1-D wave surface, 120 columns; wave step ×2 per frame:
  `v[i] += 0.12*(h[i-1]+h[i+1]-2h[i]) - 0.004*h[i]`, damping ×0.993.
- Impact: impulse ∝ drop radius at the impact column, 5 splash droplets, level rises
  `+0.055 + r*0.003` (≈ 10 drops to finish). Plink haptic per impact.
- Dashed copper target line at 72% height; when the pool surface reaches it → copper burst
  finish (see §2).

### 3.4 Loosen the knot (`knot`)
Title "Loosen the knot" · Hint "Trace circles over it until it relaxes."
- A closed loop of 90 points around center (50%, 58%), base radius 92pt; each point has
  radial noise `n = ±(26 + rand*26)` and angular jitter, relaxation `s = 0` → looks like a
  tangled scribble; slow idle rotation (full turn ≈ 75s) and wobble that dies as it relaxes.
- Tracing: points within 62pt of the finger gain `s += 0.09 * (1 - d/62) + 0.015`.
- Point position: `radius = 92 + n*(1-s)`, angle jitter scaled by `(1-s)` — fully relaxed it
  becomes a perfect circle (a glossy coil of hair).
- Same 3-stroke rendering as combing (widths 6/4/1.4), color shifts to gold with progress.
- Reward: light blob travels once around the coil (0.8s) at progress > 0.985.
- Complete at average s > 0.94.

## 4. Assets (in `assets/`)

| File | Use | Notes |
|---|---|---|
| `comb-bg.png` | Backdrop for all rituals | Gouache botanicals, 9:16, 2k — keep center clear |
| `comb-tool.png` | Comb following finger (combing ritual) | Transparent PNG, cropped to alpha bbox, teeth down |
| `hero-baseline.png` | Already in the Xcode project (`hero-baseline` imageset) | Used on destination/welcome screen |

Generated with Nano Banana Pro in the BrandArt gouache style (see `docs/DesignSystem.md` §Imagery).

## 5. Suggested Swift shape

- `LaunchRitualCoordinator` — owns trigger roll, `lastRitualKind` (UserDefaults), remote-config frequency.
- `RitualView` (SwiftUI) — full-screen; hosts backdrop image, copy block, one of four
  `Canvas`-based ritual renderers driven by `TimelineView(.animation)`, and the skip affordance.
- Each ritual = struct conforming to a small `Ritual` protocol:
  `mutating func handle(touch:)`, `mutating func step(dt:)`, `func draw(in:size:)`,
  `var isComplete: Bool`.
- Analytics: `ritual_shown(kind)`, `ritual_completed(kind, duration)`, `ritual_skipped(kind, at)`.

## 6. Tuning knobs (make these constants)

frequency (1/3), completion thresholds (0.94), smoothing rates (0.13 / 0.09), bubble spawn
rate, wave stiffness/damping, drop gravity, finish fade (0.9s) and reveal delay (0.65s).
